CREATE VIEW yd_financial.bbb AS
  SELECT
    `y`.`HOSPTIAL_NAME`    AS `HOSPTIAL_NAME`,
    `y`.`HOSPTAIL_ID`      AS `HOSPTAIL_ID`,
    sum(`y`.`TRADE_MONEY`) AS `sum(TRADE_MONEY)`
  FROM `yd_financial`.`yd_trade` `y`
  WHERE ((1 = 1) AND (`y`.`UPLINR_OR_UNDERLINE` = 'underLine') AND (`y`.`TRADE_TYPE` = 0))
  GROUP BY `y`.`HOSPTAIL_ID`;
