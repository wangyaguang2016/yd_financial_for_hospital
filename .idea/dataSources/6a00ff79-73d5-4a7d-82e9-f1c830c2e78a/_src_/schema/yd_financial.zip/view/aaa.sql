CREATE VIEW yd_financial.aaa AS
  SELECT
    `y`.`HOSPTIAL_NAME`    AS `HOSPTIAL_NAME`,
    `y`.`HOSPTAIL_ID`      AS `HOSPTAIL_ID`,
    sum(`y`.`TRADE_MONEY`) AS `sum(TRADE_MONEY)`
  FROM `yd_financial`.`yd_trade` `y`
  WHERE ((1 = 1) AND (`y`.`UPLINR_OR_UNDERLINE` = 'upLine') AND (`y`.`TRADE_TYPE` = '充值'))
  GROUP BY `y`.`HOSPTAIL_ID`;
