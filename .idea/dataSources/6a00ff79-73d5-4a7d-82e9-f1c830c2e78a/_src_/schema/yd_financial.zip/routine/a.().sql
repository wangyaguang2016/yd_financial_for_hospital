CREATE PROCEDURE yd_financial.a()
  BEGIN


    SELECT

      y.HOSPTIAL_NAME,
      y.HOSPTAIL_ID,
      sum(TRADE_MONEY)
    FROM
      yd_trade as y
    WHERE
      1 = 1
      AND UPLINR_OR_UNDERLINE = 'upLine'
      AND TRADE_TYPE='充值'
    GROUP BY
      HOSPTAIL_ID;

    SELECT
      y.HOSPTIAL_NAME,
      y.HOSPTAIL_ID,
      sum(TRADE_MONEY)
    FROM
      yd_trade as y
    WHERE
      1 = 1
      AND UPLINR_OR_UNDERLINE = 'underLine'
      AND TRADE_TYPE=0
    GROUP BY
      HOSPTAIL_ID;


  END;
